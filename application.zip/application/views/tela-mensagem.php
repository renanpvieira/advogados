<br /><br /><br /><br /><br />
<div class="container">
    <h3 class="texto-msg"><?php echo $msg; ?></h3>
</div>   